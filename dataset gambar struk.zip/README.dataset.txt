# cord > 2023-01-05 12:50pm
https://universe.roboflow.com/ml1/cord-npfb4

Provided by a Roboflow user
License: CC BY 4.0

