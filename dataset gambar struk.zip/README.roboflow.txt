
cord - v2 2023-01-05 12:50pm
==============================

This dataset was exported via roboflow.com on March 20, 2026 at 12:05 PM GMT

Roboflow is an end-to-end computer vision platform that helps you
* collaborate with your team on computer vision projects
* collect & organize images
* understand and search unstructured image data
* annotate, and create datasets
* export, train, and deploy computer vision models
* use active learning to improve your dataset over time

For state of the art Computer Vision training notebooks you can use with this dataset,
visit https://github.com/roboflow/notebooks

To find over 100k other datasets and pre-trained models, visit https://universe.roboflow.com

The dataset includes 409 images.
Table are annotated in YOLOv8 format.

The following pre-processing was applied to each image:

The following augmentation was applied to create 3 versions of each source image:
* Randomly crop between 0 and 8 percent of the image
* Random rotation of between -30 and +30 degrees
* Random shear of between -15° to +15° horizontally and -15° to +15° vertically


